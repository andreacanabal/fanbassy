# FANBASSY — Deploy Instructions
# GitHub + Railway (backend) + Vercel (frontend)
# Tiempo estimado: 45 minutos

==============================================================
PASO 1 — REQUISITOS
==============================================================

Instala en tu computadora:
- Node.js 20+ → https://nodejs.org (descarga LTS)
- Git         → https://git-scm.com

Crea cuentas (todas gratis):
- https://github.com
- https://railway.app  (conecta con tu cuenta de GitHub)
- https://vercel.com   (conecta con tu cuenta de GitHub)

==============================================================
PASO 2 — GITHUB: crea el repositorio
==============================================================

1. Ve a github.com → New repository
2. Nombre: fanbassy
3. Private
4. Sin README ni .gitignore (ya los tenemos)
5. Create repository

En tu computadora, abre una Terminal:

  cd ~/Desktop         # o donde quieras guardar el proyecto
  # Copia la carpeta fanbassy/ aquí, luego:
  cd fanbassy
  git init
  git add .
  git commit -m "Initial commit"
  git remote add origin https://github.com/TU_USUARIO/fanbassy.git
  git branch -M main
  git push -u origin main

==============================================================
PASO 3 — RAILWAY: backend + base de datos
==============================================================

3.1 Crea el proyecto
  - Ve a railway.app → New Project
  - Deploy from GitHub repo → selecciona "fanbassy"
  - Cuando pregunte el directorio: escribe "backend"
  - Railway detecta Node.js automáticamente → Deploy Now

3.2 Agrega PostgreSQL
  - En el mismo proyecto → + New → Database → PostgreSQL
  - Railway crea y conecta la BD automáticamente
  - Ve a la BD → Data → Query y ejecuta TODO el contenido de:
    backend/src/db/migrations/001_schema.sql

3.3 Configura las variables de entorno
  - Ve a tu servicio "backend" → Variables → Add Variable

  NODE_ENV         = production
  JWT_EXPIRES_IN   = 7d
  JWT_SECRET       = [genera con: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"]
  FRONTEND_URL     = https://fanbassy.vercel.app
  DATABASE_URL     = [se llenó automático — no lo cambies]

3.4 Verifica el deploy
  - Ve a tu servicio backend → Deployments → copia la URL pública
  - Abre en el browser: https://TU-BACKEND.railway.app/health
  - Debes ver: {"ok":true,"ts":"..."}

  Guarda esa URL: la necesitas en el paso 4.

==============================================================
PASO 4 — VERCEL: frontend
==============================================================

4.1 Importa el proyecto
  - Ve a vercel.com → Add New Project
  - Import Git Repository → selecciona "fanbassy"
  - Root Directory: frontend
  - Framework Preset: Vite
  
4.2 Variables de entorno (en Vercel antes de hacer clic en Deploy)
  - Clic en "Environment Variables"
  
  VITE_API_URL = https://TU-BACKEND.railway.app/api
  VITE_WS_URL  = wss://TU-BACKEND.railway.app

  (reemplaza TU-BACKEND con la URL real de Railway del paso 3.4)

4.3 Deploy
  - Clic en Deploy
  - Espera 2-3 minutos
  - Vercel te da tu URL: https://fanbassy.vercel.app (o similar)

==============================================================
PASO 5 — CONECTA FRONTEND ↔ BACKEND
==============================================================

Actualiza la variable FRONTEND_URL en Railway con la URL real de Vercel:

  - Railway → backend → Variables
  - FRONTEND_URL = https://fanbassy-xxxx.vercel.app  ← tu URL real

Railway redespliega automáticamente en ~1 minuto.

==============================================================
PASO 6 — PRUEBA QUE FUNCIONA
==============================================================

Abre tu URL de Vercel en el browser:

1. Registra una cuenta nueva con un email real
2. Inicia sesión
3. Deposita un monto (simulado en esta versión)
4. Ve que el saldo se actualiza
5. Apuesta en una predicción
6. Espera a que el countdown llegue a 0
7. Si ganaste, debe aparecer la notificación grande

Para verificar que los datos están en PostgreSQL:
  - Railway → PostgreSQL → Data
  - Tabla "users" → debe aparecer tu usuario
  - Tabla "wallets" → debe aparecer tu saldo

==============================================================
PASO 7 — FLUJO DE TRABAJO DIARIO
==============================================================

Cada vez que hagas cambios:

  git add .
  git commit -m "describe tu cambio"
  git push origin main

  → Railway redespiega el backend automáticamente (~2 min)
  → Vercel redespiega el frontend automáticamente (~1 min)

==============================================================
VARIABLES DE ENTORNO — RESUMEN COMPLETO
==============================================================

RAILWAY (backend):
  NODE_ENV         = production
  PORT             = 4000              ← Railway lo pone automático
  DATABASE_URL     = postgresql://...  ← Railway lo pone automático
  JWT_SECRET       = [string larga aleatoria de 64+ chars]
  JWT_EXPIRES_IN   = 7d
  FRONTEND_URL     = https://TU-URL.vercel.app

VERCEL (frontend):
  VITE_API_URL     = https://TU-BACKEND.railway.app/api
  VITE_WS_URL      = wss://TU-BACKEND.railway.app

==============================================================
SOLUCIÓN DE PROBLEMAS COMUNES
==============================================================

Error: "Cannot connect to database"
→ Verifica que DATABASE_URL esté en las variables de Railway
→ Verifica que ejecutaste el schema SQL en la BD

Error: "CORS error" en el browser
→ Verifica que FRONTEND_URL en Railway sea exactamente tu URL de Vercel
→ Sin "/" al final: https://fanbassy.vercel.app ✓  (no: https://fanbassy.vercel.app/)

Error: "Invalid token"
→ Verifica que JWT_SECRET esté configurado en Railway
→ El usuario tiene que volver a hacer login si cambiaste el secret

WebSocket no conecta
→ En Vercel usa wss:// (no ws://) para producción
→ Railway soporta WebSocket nativamente

Build falla en Vercel
→ Revisa que VITE_API_URL esté configurado ANTES de hacer deploy
→ Las variables VITE_* deben estar en Vercel, no solo en .env.local

==============================================================
ESTRUCTURA FINAL DEL PROYECTO
==============================================================

fanbassy/
├── .gitignore
├── README.md
├── backend/
│   ├── .gitignore
│   ├── .env.example        ← copia a .env para desarrollo local
│   ├── package.json
│   ├── railway.toml
│   └── src/
│       ├── index.js         ← entrada del servidor
│       ├── ws.js            ← WebSocket engine
│       ├── db/
│       │   ├── index.js
│       │   └── migrations/
│       │       └── 001_schema.sql
│       ├── middleware/
│       │   ├── auth.middleware.js
│       │   └── error.middleware.js
│       ├── routes/
│       │   ├── auth.routes.js
│       │   ├── wallet.routes.js
│       │   ├── predictions.routes.js
│       │   └── admin.routes.js
│       └── services/
│           ├── auth.service.js
│           ├── wallet.service.js
│           └── prediction.service.js
└── frontend/
    ├── .gitignore
    ├── .env.example        ← copia a .env.local para desarrollo local
    ├── package.json
    ├── vite.config.js
    ├── vercel.json
    ├── index.html
    └── src/
        ├── main.jsx
        ├── api.js           ← cliente HTTP + WebSocket
        └── App.jsx          ← toda la UI
