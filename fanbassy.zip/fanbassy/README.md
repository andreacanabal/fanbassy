# Fanbassy

Sports micro-prediction platform.

## Stack
- **Frontend**: React + Vite → Vercel
- **Backend**: Node.js + Express → Railway
- **Database**: PostgreSQL → Railway

## Deploy
See `/backend/README.md` and `/frontend/README.md`
